function checkEmail(index){
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var email_str = document.querySelector("#email-address").value;
    if(email_str.match(mailformat)){
        return true;
    }else{
        switch(index){
            case 1:
                alert("メールアドレスが間違っています。再入力してください。");
                break
            case 2:
                alert("Invalid email format. Please input again !");
                break
        }
        return false;
    }
}

function executeInsertEntry() {
	var entryBtn = document.querySelector("#btn--entry");

	entryBtn.onclick = function() {
		var index = 1;
		if(location.pathname.indexOf("PJHomePage/en/")!= -1){
			index = 2;
		}
		if((checkEmail(index)==false)){
			document.querySelector("#email-address").focus();
			// document.querySelector("#email").style.outlineColor = "red";
			return false;
		}

		var aTags = document.getElementsByTagName('a');
		for (var i = 0; i < aTags.length; i++) {
			var a = aTags[i];
			if (a.title === 'Upload selected files') {
				a.click();
			}
		}

	setTimeout(function() {
			var agreeCheckbox = document.querySelector("input[name=agree]").checked;
			if (agreeCheckbox) {
				$.ajax({
					// url: "/api/function/Controller.php", data: {
					// 	action: "EntryController/register",
					url: "http://10.172.68.81:3000/", data: {
						action: "entry",

						Desired_Occupation: document.querySelector("#entry__content-input").value,
						Kanji_Last_Name: document.querySelector("#input-surname-kanji").value,
						Kanji_First_Name: document.querySelector("#input-firstname-kanji").value,
						Kana_Last_Name: document.querySelector("#input-surname-katakana").value,
						Kana_First_Name: document.querySelector("#input-firstname-katakana").value,
						Alphabet_Last_Name: document.querySelector("#input-surname-alpha").value,
						Alphabet_First_Name: document.querySelector("#input-firstname-alpha").value,
						ZipCode: document.querySelector("#input-postal-code").value,
						Address: document.querySelector("#input-address").value,
						Email: document.querySelector("#email-address").value,
						Final_Education: document.querySelector("#education").value,
						Department_Faculty: document.querySelector("#major").value,
						Current_Occupation: document.querySelector("#now-work").value,
						Resume: document.querySelector("#input-file").value
					}, success: function(result) {
						if (result == 1) {
							alert("送信完了しました。ありがとうございました。");
							window.location.reload();
						} else {
							console.log(result);
						}
					}, error: function() {
						alert("Time out");
					}, timeout: 10000
				});
			} else {
				alert("送信するには「個人情報の取り扱いについて」同意が必要です。");
			}
	}, 1000);
		}
}

function start() {
	document.querySelector("#entry__content-input").value = window.localStorage.getItem('job-title');
	var detailLink = document.querySelector(".detail-link");
	detailLink.setAttribute('href', window.localStorage.getItem('detail-job-link'));
	executeInsertEntry();
}

start();