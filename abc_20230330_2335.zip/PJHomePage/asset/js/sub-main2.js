
function getJobList(callback){
    var api="http://localhost:3000/job-list";
    fetch(api)
    .then(function(response){
        return response.json()
    })
    .then(callback)
}

function start(){
    getJobList(function(jobList){
        renderJobList(jobList);
    })
}

function renderJobList(jobList){
    var elementJobList = document.querySelector(".job-list__content");
    var jobListHtml = jobList.map(function(jobList){
        return `                       
            <div class="job-list__content-item">
            <div class="job-list__content-item-img">
                <img class="job-list__content-item-img--image" src="../asset/img/${jobList.image}">
            </div>
            <div class="job-list__content-item-summary">
                <p class="job-list__content-item-summary--new">${jobList.new}</p>
                <p class="job-list__content-item-summary--title">${jobList.title}</p>
                <p class="job-list__content-item-summary--detail">${jobList.sumary}
                </p>
                <button class="job-list__content-item-summary--button" value="${jobList.id}" onclick="window.location='../recruitment/detail-job.html'">詳細</button>
            </div>
            </div>
            `
    });
    elementJobList.innerHTML = jobListHtml.join(' ');
}

start();