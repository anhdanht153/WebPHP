function insertContactUs(data){
    // var api="http://localhost:3000/inquiry";
    // var api="http://10.172.68.81:3000/inquiry";
    var api="../api/function/Controller.php?action=InquiryController/register";
    var option = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            // 'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: JSON.stringify(data)
    }
    fetch(api,option)
    .then(function(response){
        alert("送信が完了しました。ありがとうございました。");
        // 　window.location.reload();
    })
    .catch(function(){
        alert("送信が失敗になりました。");
    })
    .finally(function(){
        console.log("送信中です。");
    })
}

function executeInsertContactUs(){
    var contactUsBtn = document.querySelector("button[name=submit]");
    contactUsBtn.onclick = function(){
        var agreeCheckbox = document.querySelector("input[name=agree]").checked; 
        if(agreeCheckbox){
            var entryData = {
                Category: document.querySelector("#select").value,
                Last_Name: document.querySelector("#family-name").value,
                First_Name: document.querySelector("#name").value,
                Email: document.querySelector("#email").value,
                Company_Name: document.querySelector("#company-name").value,
                Subject: document.querySelector("#subject").value,
                Content: document.querySelector("#content").value,
            }
             insertContactUs(entryData);
        console.log(entryData);
        }else{
            alert("送信するには同意にチェックしないといけないんです。");
        }

    }
}

function start(){
    executeInsertContactUs();
}

start();