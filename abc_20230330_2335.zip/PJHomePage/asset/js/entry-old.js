function insertEntry(data) {
	var api = "/api/function/Controller.php?action=EntryController/register";
	var option = {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			// 'Content-Type': 'application/x-www-form-urlencoded',
		},
		body: JSON.stringify(data)
	}
	fetch(api, option)
		.then(function(response) {
			if (response == 1) {
				alert("送信がもう完了しました。");
				window.location.reload();
			} else {
				console.log(response);
			}
		})
		.catch(function() {
			alert("送信が失敗になりました。");
		})
		.finally(function() {
			console.log("送信中です。");
		})
}

function executeInsertEntry() {
	var entryBtn = document.querySelector("#btn--entry");

	entryBtn.onclick = function() {
var aTags = document.getElementsByTagName('a');
for (var i = 0; i < aTags.length; i++) {
  var a = aTags[i];
  if (a.title === 'Upload selected files') {
    a.click();
  }
}
setTimeout(function() {
		var agreeCheckbox = document.querySelector("input[name=agree]").checked;
		if (agreeCheckbox) {
			{
				// var entry_title         = document.querySelector("#entry__content-input").value;
				// var surname_kanji       = document.querySelector("#input-surname-kanji").value;
				// var firstname_kanji     = document.querySelector("#input-firstname-kanji").value;
				// var surname_katakana    = document.querySelector("#input-surname-katakana").value;
				// var firstname_katakana  = document.querySelector("#input-firstname-katakana").value;
				// var surname_alpha       = document.querySelector("#input-surname-alpha").value;
				// var firstname_alpha     = document.querySelector("#input-firstname-alpha").value;
				// var postal_cost         = document.querySelector("#input-postal-code").value;
				// var address             = document.querySelector("#input-address").value;
				// var email_address       = document.querySelector("#email-address").value;
				// var education           = document.querySelector("#education").value;
				// var major               = document.querySelector("#major").value;
				// var now_work            = document.querySelector("#now-work").value;
				// var input_file          = document.querySelector("#input-file").value;
			}

			var entryData = {
				// Desired_Occupation: entry_title,
				// Kanji_Last_Name: surname_kanji,
				// Kanji_First_Name: firstname_kanji,
				// Kana_Last_Name: surname_katakana,
				// Kana_First_Name: firstname_katakana,
				// Alphabet_Last_Name: surname_alpha,
				// Alphabet_First_Name: firstname_alpha,
				// ZipCode: postal_cost,
				// Address: address,
				// Email: email_address,
				// Final_Education: education,
				// Department_Faculty: major,
				// Current_Occupation: now_work,
				// Resume: input_file

				Desired_Occupation: document.querySelector("#entry__content-input").value,
				Kanji_Last_Name: document.querySelector("#input-surname-kanji").value,
				Kanji_First_Name: document.querySelector("#input-firstname-kanji").value,
				Kana_Last_Name: document.querySelector("#input-surname-katakana").value,
				Kana_First_Name: document.querySelector("#input-firstname-katakana").value,
				Alphabet_Last_Name: document.querySelector("#input-surname-alpha").value,
				Alphabet_First_Name: document.querySelector("#input-firstname-alpha").value,
				ZipCode: document.querySelector("#input-postal-code").value,
				Address: document.querySelector("#input-address").value,
				Email: document.querySelector("#email-address").value,
				Final_Education: document.querySelector("#education").value,
				Department_Faculty: document.querySelector("#major").value,
				Current_Occupation: document.querySelector("#now-work").value,
				Resume: document.querySelector("#input-file").value
			}
			//insertEntry(entryData);
			$.ajax({
				url: "/api/function/Controller.php", data: {
					action: "EntryController/register",

					Desired_Occupation: document.querySelector("#entry__content-input").value,
					Kanji_Last_Name: document.querySelector("#input-surname-kanji").value,
					Kanji_First_Name: document.querySelector("#input-firstname-kanji").value,
					Kana_Last_Name: document.querySelector("#input-surname-katakana").value,
					Kana_First_Name: document.querySelector("#input-firstname-katakana").value,
					Alphabet_Last_Name: document.querySelector("#input-surname-alpha").value,
					Alphabet_First_Name: document.querySelector("#input-firstname-alpha").value,
					ZipCode: document.querySelector("#input-postal-code").value,
					Address: document.querySelector("#input-address").value,
					Email: document.querySelector("#email-address").value,
					Final_Education: document.querySelector("#education").value,
					Department_Faculty: document.querySelector("#major").value,
					Current_Occupation: document.querySelector("#now-work").value,
					Resume: document.querySelector("#input-file").value
				}, success: function(result) {
					if (result == 1) {
						alert("送信完了しました。ありがとうございました。");
						window.location.reload();
					} else {
						console.log(result);
					}
				}, error: function() {
					alert("Time out");
				}, timeout: 10000
			});
		} else {
			alert("送信するには同意しないといけないんです。");
		}
}, 1000);
	}
}

function start() {
	executeInsertEntry();
}

start();