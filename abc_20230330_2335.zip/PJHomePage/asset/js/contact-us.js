function checkEmail(index){
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var email_str = document.querySelector("#email").value;
    if(email_str.match(mailformat)){
        return true;
    }else{
        switch(index){
            case 1:
                alert("メールアドレスが間違っています。再入力してください。");
                break
            case 2:
                alert("Invalid email format. Please input again !");
                break
        }
        return false;
    }
}

function executeInsertContactUs(){
    var contactUsBtn = document.querySelector("button[name=submit]");
    contactUsBtn.onclick = function(){
        var index = 1;
        if(location.pathname.indexOf("PJHomePage/en/")!= -1){
            index = 2;
        }
        if((checkEmail(index)==false)){
            document.querySelector("#email").focus();
            // document.querySelector("#email").style.outlineColor = "red";
            return false;
        }
        var agreeCheckbox = document.querySelector("input[name=agree]").checked; 
        if(agreeCheckbox){
            $.ajax({
				url: "/api/function/Controller.php", data: {
					action: "InquiryController/register",

                    Category: document.querySelector("#select").value,
                    Last_Name: document.querySelector("#family-name").value,
                    First_Name: document.querySelector("#name").value,
                    Email: document.querySelector("#email").value,
                    Company_Name: document.querySelector("#company-name").value,
                    Subject: document.querySelector("#subject").value,
                    Content: document.querySelector("#content").value,
				}, success: function(result) {
					if (result == 1) {
						alert("送信完了しました。ありがとうございました。");
						window.location.reload();
					} else {
						console.log(result);
					}
				}, error: function() {
					alert("Time out");
				}, timeout: 10000
			});
        }else{
            alert("送信するにはを同意が必要です。");
        }

    }
}

function start(){
    executeInsertContactUs();
}

start();