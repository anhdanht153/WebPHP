// var bodyElement = document.querySelector("body");
//     bodyElement.onload = drawCircle();
//     bodyElement.onresize = drawCircle();

function drawCircle(){
    var bodyElement = document.querySelector("body");
    var heightCircle = Math.round(bodyElement.clientWidth/2);
    var heightCircleString = heightCircle + "px";
    var borderRadius = bodyElement.clientWidth +"px " + bodyElement.clientWidth +"px 0 0";
    var circleElement = document.querySelectorAll(".half-circle__video");
    for(var i=0;i<circleElement.length;i++) {
        circleElement[i].style.height = heightCircleString;
        circleElement[i].style.borderRadius = borderRadius;
    }
}

/**
 * 会社概要ページ
 * 列色の変更
 */
function changeColorForTableRow(){
    var $rowArray = document.getElementsByTagName("tr");
    // $rowArray = document.querySelectorAll("content__table-row");
    $rowLength = $rowArray.length;
    for(var i=0; i<= $rowLength; i++){
        if(i%2 == 0){
            $rowArray[i].style.background = "#f5f4f4";
        }
    }
}

/**
 * 沿革ページ
 * 線を引く
 */
function drawLine(){
    var yearElements = document.querySelectorAll(".history__table-column-year");
    var yearElementsLength = yearElements.length;
    for(var i=0; i<yearElementsLength; i++){
        if(yearElements[i].innerHTML !=""){
            yearElements[i].parentNode.style.borderTop="1px solid #727171";
        }
    }
    yearElements[yearElementsLength-1].parentNode.style.borderBottom="1px solid #727171";
}

/**
 * 各ページ
 * ページのPath
 */
function updateLengthOfPagePath(){
    var bannerElement = document.querySelector(".banner");
    var pagePathElement = document.querySelector(".page-path");
    var length = bannerElement.clientWidth + "px";
    pagePathElement.style.width = length;

}

/**
 * 英語に切り替える
 */
function changeToEnglish(){
    // console.log("link cu =", location.pathname);
    // console.log("link moi =", location.pathname.replace("/PJHomePage/","/PJHomePage/en/"));
    window.location.href = location.pathname.replace("/PJHomePage/","/PJHomePage/en/");
}

function changeToJapanese(){
    // console.log("link cu =", location.pathname);
    // console.log("link moi =", location.pathname.replace("/PJHomePage/en/","/PJHomePage/"));
    window.location.href = location.pathname.replace("/PJHomePage/en/","/PJHomePage/");
}