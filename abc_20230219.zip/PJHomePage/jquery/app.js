/**
 * 矢印をクリックするとサービス所へ移動する
 */
$(document).ready(function(){
    $(".half-circle__arrow").click(function(){
    var logoHeight = $("header").css("height");
    $('html, body').animate({
        // scrollTop: $("#service-container").offset().top-110
        // scrollTop: $("#service-container").offset().top-parseInt(logoHeight)
        scrollTop: $(".service--background-color-linear").offset().top-parseInt(logoHeight)
    }, 2000);

    });
})