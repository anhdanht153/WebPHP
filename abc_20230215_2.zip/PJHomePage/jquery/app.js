/**
 * 矢印をクリックするとサービス所へ移動する
 */
$(document).ready(function(){
    $(".local-service-arrow").click(function(){
    var logoHeight = $("#logoMenu").css("height");
    $('html, body').animate({
        // scrollTop: $("#service-container").offset().top-110
        scrollTop: $("#service-container").offset().top-parseInt(logoHeight)
    }, 1500);

    });
})