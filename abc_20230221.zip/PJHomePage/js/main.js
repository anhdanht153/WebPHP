// var bodyElement = document.querySelector("body");
//     bodyElement.onload = drawCircle();
//     bodyElement.onresize = drawCircle();

function drawCircle(){
    var bodyElement = document.querySelector("body");
    var heightCircle = Math.round(bodyElement.clientWidth/2);
    var heightCircleString = heightCircle + "px";
    var borderRadius = bodyElement.clientWidth +"px " + bodyElement.clientWidth +"px 0 0";

    var circleElement = document.querySelector(".half-circle__video")
    // console.log(bodyElement.clientWidth);
    // console.log(heightCircleString);
    // console.log(circleElement);
    // console.log(borderRadius);
    circleElement.style.height = heightCircleString;
    circleElement.style.borderRadius = borderRadius;
}

/**
 * 列色の変更
 */
function changeColorForTableRow(){
    $rowArray = document.getElementsByTagName("tr");
    // $rowArray = document.querySelectorAll("content__table-row");
    $rowLength = $rowArray.length;
    for(var i=0; i<= $rowLength; i++){
        if(i%2 == 0){
            $rowArray[i].style.background = "#f5f4f4";
        }
    }
}