
function getJobList(callback){
    var api="http://localhost:3000/job-list";
    fetch(api)
    .then(function(response){
        return response.json()
    })
    .then(callback)
}

function start(){
    getJobList(function(jobList){
        renderJobList(jobList);
    })
}

function renderJobList(jobList){
    var elementJobList = document.querySelector(".job-list__content");
    var jobListHtml = jobList.map(function(jobList){
        return `                       
            <div class="job-list__content-item">
            <div class="job-list__content-item-img">
                <img class="job-list__content-item-img--image" src="../asset/img/${jobList.photo}">
            </div>
            <div class="job-list__content-item-summary">
                <p class="job-list__content-item-summary--new">New</p>
                <p class="job-list__content-item-summary--title">${jobList.title.replace(/@@@/g,"\r\n")}</p>
                <p class="job-list__content-item-summary--detail">${jobList.content.replace(/@@@/g,"\r\n")}
                </p>
                <button class="job-list__content-item-summary--button" value="${jobList.id}" onclick="window.location='../recruitment/detail-job.html?id=${jobList.id}'">詳細</button>
            </div>
            </div>
            `
    });
    elementJobList.innerHTML = jobListHtml.join(' ');
}

start();