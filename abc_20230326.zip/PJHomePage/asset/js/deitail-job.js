
// Get job id
function getJobId(){
    var url_link = location.href;
    var id_index = url_link.lastIndexOf("id");
    return job_id = url_link.substring(id_index+3);
}

function getJob(callback){
    var job_id = getJobId();
    var api="http://localhost:3000/job-list/"+job_id;
    console.log(api);
    fetch(api)
    .then(function(response){
        return response.json();
    })
    .then(callback)
}

function start(){
    getJob(function(job){
        renderJob(job);
    })
}

function renderJob(job){
    var title = document.querySelector(".detail-job__sub-title--black");
    var type_of_employee = document.querySelector("#type-of-employee");
    var work_location = document.querySelector("#work-location");
    var job_content = document.querySelector("#job-content");
    var job_requirement = document.querySelector("#job-requirement");
    var language_requirement = document.querySelector("#language-requirement");
    var work_time = document.querySelector("#work-time");
    var probationary = document.querySelector("#probationary");
    var salary = document.querySelector("#salary");

    title.innerHTML                 = job.title.replace(/@@@/g,"\r\n");
    type_of_employee.innerHTML      = job.Type_of_employment.replace(/@@@/g,"\r\n");
    work_location.innerHTML         = job.Work_location.replace(/@@@/g,"\r\n");
    job_content.innerHTML           = job.Job_responsibilities.replace(/@@@/g,"\r\n");
    job_requirement.innerHTML       = job.Job_requirements.replace(/@@@/g,"\r\n");
    language_requirement.innerHTML  = job.Language_skills.replace(/@@@/g,"\r\n");
    work_time.innerHTML             = job.Working_hours.replace(/@@@/g,"\r\n");
    probationary.innerHTML          = job.Probationary_period.replace(/@@@/g,"\r\n");
    salary.innerHTML                = job.Salary.replace(/@@@/g,"\r\n");
}

start();