function insertContactUs(data){
    var api="http://localhost:3000/inquiry";
    var option = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            // 'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: JSON.stringify(data)
    }
    fetch(api,option)
    .then(function(response){
        alert("送信がもう完了しました。");
        window.location.reload();
    })
    .catch(function(){
        alert("送信が失敗になりました。");
    })
    .finally(function(){
        console.log("送信中です。");
    })
}

function executeInsertContactUs(){
    var contactUsBtn = document.querySelector("button[name=submit]");

    contactUsBtn.onclick = function(){
        var agreeCheckbox = document.querySelector("input[name=agree]").checked; 
        if(agreeCheckbox){
            var entryData = {
                Category: document.querySelector("#select").value,
                Last_Name: document.querySelector("#family-name").value,
                First_Name: document.querySelector("#name").value,
                Email: document.querySelector("#email").value,
                Company_Name: document.querySelector("#education").value,
                Subject: document.querySelector("#subject").value,
                Content: document.querySelector("#content").value,
            }
            insertContactUs(entryData);
        }else{
            alert("送信するには同意しないといけないんです。");
        }

    }
}

function start(){
    executeInsertContactUs();
}

start();

https://pegaservice-japan.pegatroncorp.com/api/function/Controller.php?action=InquiryController/findAll/findAll()

https://pegaservice-japan.pegatroncorp.com/api/function/Controller.php?action=InquiryController/register
{
    "id": "0",
    "Category": "@Category@<input type=\"hidden\" value=\"0\">",
    "Last_Name": "@Last_Name@",
    "First_Name": "@First_Name@",
    "Email": "@Email@",
    "Company_Name": "@Company_Name@",
    "Subject": "@Subject@",
    "Content": "@Content@",
    "create_date": "-0001年11月30日(火)",
    "update_date": "-0001年11月30日(火)"
  }
