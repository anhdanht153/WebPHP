    // var apiLink = "/api/function/Controller.php?action=UserController/read&id=4";
    // fetch(apiLink)
    // .then((response)=>{
    //     console.log(response.json);
    // });


    https://pegaservice-japan.pegatroncorp.com/api/function/Controller.php?action=LanguageController/findAll

    https://pegaservice-japan.pegatroncorp.com/api/function/Controller.php?action=LanguageController/read&id=2
    
    https://pegaservice-japan.pegatroncorp.com/api/function/Controller.php?action=LanguageController/getDataByPageAndLang



    var apiLink = "/api/function/Controller.php?action=LanguageController/findAll";
    fetch(apiLink)
    .then((response)=>{
        console.log(response.json);
    });
