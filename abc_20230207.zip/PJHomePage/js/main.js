// var bodyElement = document.querySelector("body");
//     bodyElement.onload = drawCircle();
//     bodyElement.onresize = drawCircle();

function drawCircle(){
    var bodyElement = document.querySelector("body");
    var heightCircle = Math.round(bodyElement.clientWidth/2);
    var heightCircleString = heightCircle + "px";

    var circleElement = document.querySelector(".half-circle-container")
    console.log(bodyElement.clientWidth);
    console.log(heightCircleString);
    circleElement.style.height = heightCircleString;
}


